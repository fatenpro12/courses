<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Instructor extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable=['name','birth_date','job_title','description','level_number','id_photo'];

    public function courses()
    {
        return $this->hasMany(Course::class,'instructer_id');
    }
    public function reviews()
    {
        return $this->hasMany(Review::class,'instructer_id');
    }
}
