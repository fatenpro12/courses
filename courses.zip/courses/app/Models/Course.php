<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Course extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable =
    ['name','description','category_id','instructer_id',
    'address_id','session_count','level_count'];

    public function category(){
        return $this->belongsTo(Category::class,'category_id');
    }
    public function address(){
        return $this->belongsTo(Address::class,'address_id');
    }
    public function instucter(){
        return $this->belongsTo(Instructor::class,'instructer_id');
    }
    public function contents()
    {
        return $this->hasMany(Content::class,'course_id');
    }
    public function orders()
    {
        return $this->hasMany(Order::class,'course_id');
    }
    public function results()
    {
        return $this->hasMany(Result::class,'course_id');
    }
    public function schedules()
    {
        return $this->hasMany(Schedule::class,'course_id');
    }
    public function absents()
    {
        return $this->hasMany(Absent::class,'course_id');
    }
}
