<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Schedule extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable=['course_id','date','from','to','level_number'];

    protected $dates=['date'];

    public function course()
    {
        return $this->belongsTo(Course::class,'course_id');
    }
    public function absents()
    {
        return $this->hasMany(Absent::class,'schedule_id');
    }

}
