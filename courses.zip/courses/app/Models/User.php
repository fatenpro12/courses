<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;
use Tymon\JWTAuth\Contracts\JWTSubject;

class User extends Authenticatable implements JWTSubject
{
    use HasFactory, Notifiable,SoftDeletes, HasRoles;

    const USER_ROLE_ADMIN_USER = 'admin';

    const USER_ROLE_MANAGER_USER = 'manager';

    const USER_ROLE_STANDARD_USER = 'user';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'email','qr','unhashed_password',
        'password','address','first_name','last_name','study_state','id_photo','nationality'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function isAdmin() : bool
    {
        return $this->hasRole(self::USER_ROLE_ADMIN_USER);
    }
    public function isManager() : bool
    {
        return $this->hasRole(self::USER_ROLE_MANAGER_USER);
    }

    public static function getUsersByType(string $type)
    {
        return User::whereHas('roles' , function($q ) use ($type){
            $q->where('name', $type);
        })->get();
    }
    public function orders()
    {
        return $this->hasMany(Order::class,'user_id');
    }
    public function results()
    {
        return $this->hasMany(Result::class,'user_id');
    }
    public function reviews()
    {
        return $this->hasMany(Result::class,'user_id');
    }
    public function absents()
    {
        return $this->hasMany(Absent::class,'user_id');
    }

    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }
    public function getJWTCustomClaims()
    {
        return [];
    }
}
