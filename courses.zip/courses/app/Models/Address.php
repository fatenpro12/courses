<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Address extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable=['city','lat','lng','street_name','house_number','post_code'];

    public function courses()
    {
        return $this->hasMany(Course::class,'level_id');
    }
}
