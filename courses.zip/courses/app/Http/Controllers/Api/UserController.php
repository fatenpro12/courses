<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\UserLoginRequest;
use App\Http\Requests\UserRequest;
use App\Http\Resources\UserResource;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Hash;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Exceptions\TokenExpiredException;
use Tymon\JWTAuth\Exceptions\TokenInvalidException;
use Tymon\JWTAuth\Facades\JWTAuth;


class UserController extends Controller
{

    public function index()
    {
        return UserResource::collection(User::paginate(20));
    }


    public function store(UserRequest $request)
    {
        $file=null;
        if ($request->file('file')) {

            //store file into document folder
            $file = $request->file->store('public/users/images');
            //store your file into database
        }
        $request['id_photo']=$file;
        $request['password']=Hash::make($request->get('password'));
        $request['unhashed_password']=$request->get('password');
        $user =User::create($request->all());
        return response([
            'data' => new UserResource($user)
        ],Response::HTTP_CREATED);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        return new UserResource($user);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Category  $Category
     * @return \Illuminate\Http\Response
     */

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Category  $Category
     * @return \Illuminate\Http\Response
     */
    public function update(UserRequest $request, User $user)
    {
        $file=null;
        if ($request->file('file')) {

            //store file into document folder
            $file = $request->file->store('public/users');
            $request['id_photo']=$file;
        }
        $user->update($request->all());
        $user->assignRole($request->type);
        return response([
            'data' => new UserResource($user)
        ],Response::HTTP_CREATED);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Category  $Category
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        $user->delete();
        return response(null,Response::HTTP_NO_CONTENT);
    }
    public function login(UserLoginRequest $request)
    {
        //if (!$token = JWTAuth::attempt($request->only(['email', 'password']))) {
        if (!$token = auth()->attempt($request->only(['email', 'password']))){
            return response()->json([
                'errors' => [
                    'email' => ['Sorry we cant find you with those details.'],
                ],
            ], 422);
        };
        $use=new UserResource($request->user());
        $role=$use->hasRole(User::USER_ROLE_ADMIN_USER);
        return ($use)->additional([
            [
                'token' => $token,
                'api_token' => JWTAuth::attempt($request->only(['email', 'password'])),
                'token_type' => 'bearer',
                'expires_in' => auth('api')->factory()->getTTL() * 60,
                'user_id' => $request->user()->id,//auth()->user(),
                'isAdmin'=>$role

            ],
        ]);
    }

    public function register(UserRequest $request)
    {
        $user = User::create([
            'name' => $request->get('name'),
            'email' => $request->get('email'),
            'password' => Hash::make($request->get('password')),
            'unhashed_password' => $request->get('password'),
        ]);
        if (!$token = auth()->attempt($request->only(['email', 'password']))) {
            return abort(401);
        };

        $user->assignRole(User::USER_ROLE_STANDARD_USER);
       // $token = JWTAuth::fromUser($user);

        return (new UserResource($request->user()))->additional([
            'meta' => [
                'token' => $token,
                'api_token' => JWTAuth::attempt($request->only(['email', 'password'])),
                'token_type' => 'bearer',
                'expires_in' => auth('api')->factory()->getTTL() * 60,
                'user_id' => $request->user()->id//auth()->user()

            ],
        ]);

        //return response()->json(compact('user','token'),201);
    }

    public function getAuthenticatedUser()
    {
        try {
            if (! $user = auth()) {
                return response()->json(['user_not_found'], 404);
            }

        } catch (TokenExpiredException $e) {

            return response()->json(['token_expired'], $e->getStatusCode());

        } catch (TokenInvalidException $e) {

            return response()->json(['token_invalid'], $e->getStatusCode());

        } catch (JWTException $e) {

            return response()->json(['token_absent'], $e->getStatusCode());

        }

        return response()->json(compact('user'));
}
    public function logout() {
        auth()->logout();
    }
}
