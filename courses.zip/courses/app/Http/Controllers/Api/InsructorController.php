<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\InstructorRequest;
use App\Http\Resources\InstructorResource;
use App\Models\Instructor;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class InsructorController extends Controller
{
    public function __construct()
    {
        //   $this->middleware('auth:api')->except('index','show');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return InstructorResource::collection(Instructor::paginate(20));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(InstructorRequest $request)
    {

                   /* $image = $request->id_photo;  // your base64 encoded
                    $image = str_replace('data:image/png;base64,', '', $image);
                    $image = str_replace(' ', '+', $image);
                    $imageName = \Str::random(10).'.'.'png';
                    \File::put(storage_path() . 'test.png', base64_decode($image));
                    $request['id_photo']= $imageName;
                ///     return $request['id_photo'];*/
$fileName = \Str::random(10).'.'.'jpg';
$data = $request->id_photo;//\File::get($request->id_photo);
$data = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $data));
$upload_success = \Storage::disk('local')->put('images/' . $fileName, $data);
    $request['id_photo']= $fileName;
        $instructor = Instructor::create($request->all());
        return response([
            'data' => new InstructorResource($instructor)
        ],Response::HTTP_CREATED);
    }


    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Level  $Level
     * @return \Illuminate\Http\Response
     */
    public function show(Instructor $instructor)
    {
        return new InstructorResource($instructor);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Level  $Level
     * @return \Illuminate\Http\Response
     */

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Level  $Level
     * @return \Illuminate\Http\Response
     */
    public function update(InstructorRequest $request, Instructor $instructor)
    {
        $base64_image = $request->id_photo;
        if($base64_image){
        $data=null;
        if (preg_match('/^data:image\/(\w+);base64,/', $base64_image)) {
            $data = substr($base64_image, strpos($base64_image, ',') + 1);
            $data = base64_decode($data);
        }
        else
           $data = base64_decode($data);
           $imgName=\Str::random(10).'.'.'png';
            \Storage::disk('local')->put($imgName, $data);
            $request['id_photo']= $imgName;
            }
        $instructor->update($request->all());

        return response([
            'data' => new InstructorResource($instructor)
        ],Response::HTTP_CREATED);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Level  $level
     * @return \Illuminate\Http\Response
     */
    public function destroy(Instructor $instructor)
    {
        $instructor->delete();
        return response(null,Response::HTTP_NO_CONTENT);
    }
}
