<?php

namespace App\Http\Middleware;

use App\Models\User;
use Closure;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;

class AdminRole
{
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure                 $next
     * @param string|null              $guard
     *
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {
        /*$user = auth();

        if ( $user->hasRole(User::USER_ROLE_ADMIN_USER)|| $user->hasRole(User::USER_ROLE_MANAGER_USER)) {
            return $next($request);
        }

        return  response()->json('you can\'t open link');*/
        try {
            $jwt = JWTAuth::parseToken()->authenticate();
        } catch (\Tymon\JWTAuth\Exceptions\JWTException $e) {
            $jwt = null;
        }
        if ($jwt!=null&&($jwt->hasRole(User::USER_ROLE_ADMIN_USER)||$jwt->hasRole(User::USER_ROLE_MANAGER_USER))) {
            return $next($request);
        } else {
            return response('Unauthorized.', 401);
        }
    }
}
