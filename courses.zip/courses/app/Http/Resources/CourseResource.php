<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CourseResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id'=>$this->id,
            'name' => $this->name,
            'category'=>$this->category,
            'description' => $this->description,
            'instructer' => $this->instructer,
            'levels' => $this->level_count,
            'address'=>$this->address,
            'session_count'=>$this->session_count,
            'content'=>$this->contents,
            'orders'=>$this->contents,
            'results'=>$this->results,
            'schedules'=>$this->schedules,
            'absents'=>$this->absents,
        ];
    }
}
