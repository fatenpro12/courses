<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ResultResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id'=>$this->id,
            'user' => $this->user,
            'course' => $this->course,
            'result' => $this->result,
            'mark' => $this->mark,
            'image' => $this->image,
            'level_number' => $this->level_number,

        ];
    }
}
