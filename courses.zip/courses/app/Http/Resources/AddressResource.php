<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class AddressResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id'=>$this->id,
            'city' => $this->city,
            'lat' => $this->lat,
            'lng' => $this->lng,
            'street_name' => $this->street_name,
            'house_number'=>$this->house_number,
            'post_code'=>$this->post_code,
            'courses'=>$this->courses
        ];
    }
}
