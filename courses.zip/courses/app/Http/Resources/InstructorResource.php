<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class InstructorResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id'=>$this->id,
            'id_photo'=>asset('instructor/'.$this->id_photo),
            'name' => $this->name,
            'birth_date' => $this->birth_date,
            'job_title' => $this->job_title,
            'description' => $this->description,
            'courses'=>$this->courses,
            'reviews'=>$this->reviews,
            'level_number'=>$this->level_number,

        ];
    }
}
