<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Tymon\JWTAuth\Facades\JWTAuth;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


Route::post('/register', [\App\Http\Controllers\Api\UserController::class,'register']);
Route::post('/login', [\App\Http\Controllers\Api\UserController::class,'login']);
Route::get('/getAuthenticatedUser', [\App\Http\Controllers\Api\UserController::class,'getAuthenticatedUser']);
Route::post('/logout', [\App\Http\Controllers\Api\UserController::class,'logout']);


    Route::apiResource('/users', \App\Http\Controllers\Api\UserController::class);


    Route::apiResource('/categories', \App\Http\Controllers\Api\CategoryController::class);
    Route::apiResource('/instructors', \App\Http\Controllers\Api\InsructorController::class);
    Route::apiResource('/addresses', \App\Http\Controllers\Api\AddressController::class);
    Route::apiResource('/courses', \App\Http\Controllers\Api\CourseController::class);
    Route::apiResource('/absents', \App\Http\Controllers\Api\AbsentController::class);
    Route::apiResource('/contents', \App\Http\Controllers\Api\ContentController::class);
    Route::apiResource('/results', \App\Http\Controllers\Api\ResultController::class);
    Route::apiResource('/reviews', \App\Http\Controllers\Api\ReviewController::class);
    Route::apiResource('/schedules', \App\Http\Controllers\Api\ScheduleController::class);




/*Route::group(['middleware' => ['jwt.verify']], function() {
    Route::get('user', [\App\Http\Controllers\Api\UserController::class,'getAuthenticatedUser']);
});*/
