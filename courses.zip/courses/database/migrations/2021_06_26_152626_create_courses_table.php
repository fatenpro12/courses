<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCoursesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('courses', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('description')->nullable();
            $table->string('session_count');
            $table->integer('level_count');
            $table->unsignedBigInteger('instructer_id');
            $table->unsignedBigInteger('category_id');
            $table->unsignedBigInteger('address_id');
            $table->foreign('instructer_id')->on('instructors')->references('id');
            $table->foreign('category_id')->on('categories')->references('id');
            $table->foreign('address_id')->on('addresses')->references('id');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('courses');
    }
}
